# dicionario = {
#     "nome": "Kaua",
#     "idade" : "17",
#     "cidade" : "campo grande",
#     "prefissão" : "desempregado",
# }
# print (dicionario['nome'])
# print(dicionario['idade'])

# dicionario["idade"] = 18
# dicionario["nome"] = 'shopee'

# dicionario["email"] = 'shopee@gmail.com'
# dicionario["telefone"] = '111111-1111'

# print(dicionario)
###################################################################################################################################################################
# nome = {
#     "nome1": "penisvaldo",
#     "idade": 17,
#     "nome2": "tomasturbano",
#     "idade2": 13,
#     "nome3": "kucabeludo",
#     "idade3": 19,
#     "nome4": "kevin mamar",
#     "idade4": 12,

# }
# for i in nome:
#     print(nome[i])

# name = input("digite o nome de um amigo: ")

# if name in nome.values():
#     print("esta")
# else:
#     print("não esta")
#######################################################################################################################################################################
# traducao = {
#     "hello": "olá",
#     "goodbye": "adeus",
#     "please": "por favor",
#     "thank you": "obrigado",
#     "sorry": "desculpa",
#     "yes": "sim",
#     "no": "não",
#     "man": "homem",
#     "woman": "mulher",
#     "boy": "menino",
#     "girl": "menina",
#     "dog": "cachorro",
#     "cat": "gato",
#     "food": "comida",
#     "water": "água",
#     "house": "casa",
#     "car": "carro",
#     "book": "livro",
#     "school": "escola",
#     "teacher": "professor",
#     "student": "estudante",
#     "love": "amor",
#     "friend": "amigo",
#     "family": "família",
#     "work": "trabalho",
#     "happy": "feliz",
#     "sad": "triste",
#     "day": "dia",
#     "night": "noite"
# }
# nome = input("digite uma palvra em ingles: ")

# if nome in traducao:
#     print(traducao[nome])

# else:
#     print("nao tem")
###########################################################################################################################################################################

# estoque ={
#     "nike": {"quantidade": 50, "preço": 1000},
#     "lacoste": {"quantidade": 30, "preço": 350},
#     "malbeke": {"quantidade": 20, "preço": 250},
#     "212": {"quantidade": 15, "preço": 500},
#     "uva": {"quantidade": 40, "preço": 1.20},
# }
# nome = input("digite o produto ")

# if nome in estoque:
#     print(estoque[nome])
#     print("tem estoque")


# else:
#      print("nao tem")
###########################################################################################################################################################################
# def lista (numero1, numero2, numero3):
#     soma = (numero1 * numero2 * numero3)
#     return soma
# x =lista(5,5,5)
# print(x)
#######################################################################################################################################################################3####
# def lista(n1,n3):
#     soma = n1 ** n3
#     return soma
# soma2 = lista(5,5)
# print(soma2)
#######################################################################################################################################

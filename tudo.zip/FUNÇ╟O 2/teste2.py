# def soma_numeros():
#     num1 = float(input("Digite o primeiro número: "))
#     num2 = float(input("Digite o segundo número: "))
#     soma = num1 ** num2
#     return soma
# resultado = soma_numeros()
# print(f"A soma dos números é: {resultado}")
###########################################################################################################################################################################
# def lista (valor):
#     if valor > 0:
#          return"p"
#     else:
#         return"n"
# x =lista(5)
# print(x)
#########################################################################################################################################################################
# def  soma(taxa, custo):
#     taxa = taxa/ 100
#     imposto = custo +(custo *taxa)
#     return  imposto
# res = soma(float(input("o valor da taxa é: ")), float(input("valor inicial: ")))
# print(res)
#############################################################################################################################################################################
# produtos = [
#     {"nome": f"Produto {i+1}", "preco": round(1.99+ i * 2, 2)}
#     for i in range(50)
# ]
# print(f"{'Produto':<20} {'Preço':>10}")
# print("="*30)
# for produto in produtos:
#     print(f"{produto['nome']:<20} R${produto['preco']:>10.2f}")
################################################################################################################################################################################################
# def calcular_salario(horas_trabalhadas):
#     salario_base = 40 * 10  
#     if horas_trabalhadas <= 40:
#         salario_total = horas_trabalhadas * 10
#     else:
#         horas_excedentes = horas_trabalhadas - 40
#         salario_total = salario_base + (horas_excedentes * 10 * 1.5)  
#     return salario_total
# horas_trabalhadas = float(input("Insira o número de horas trabalhadas: "))
# salario = calcular_salario(horas_trabalhadas)
# print("Salário a ser pago:", salario)
###########################################################################################################################################
# def calcularTempo(tempo_minutos):
#     if tempo_minutos < 15:
#         return 0
#     horas = tempo_minutos / 60
#     v = 9 + max(0, horas - 1) * 1.5
#     return v
# t = int(input("escreva o valor dos minutos: ")) 
# print("Valor a pagar:", calcularTempo(t))
#########################################################################################################################################3
# def imprimi(L):
#     cont = 0
#     while cont < len(L):
#         print(f"{cont+1} {L[cont]}")
#         cont+=1


# compra = ['mamão', 'mel','castanha', 'uva', 'banana', 'detergente']

# imprimi(compra)

# ########################################################################################################$
# def media(l):
#     soma = 0
#     for compra in l:
#         soma + compra
#     media = soma / len(l)
#     return media 
##############################################################################################################
# def calcular_excesso_e_multa(peso_peixes):
#     LIMITE_PESO = 50  
#     VALOR_MULTA_POR_KG = 4.00  
#     if peso_peixes > LIMITE_PESO:
#         excesso = peso_peixes - LIMITE_PESO
#         multa = excesso * VALOR_MULTA_POR_KG
#     else:
#         excesso = 0
#         multa = 0.0
#     print(f"Peso dos peixes: {peso_peixes} Kg")
#     print(f"Excesso de peso: {excesso} Kg")
#     print(f"Multa a pagar: R$ {multa}")
# peso_peixes = float(input("Digite o peso dos peixes (em Kg): "))
# calcular_excesso_e_multa(peso_peixes)
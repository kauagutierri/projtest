class Automovel:
    def __init__(self, modelo, marca="ferrari", cor="vermelho", placa="bca-0987", ano="2022"):
        self.marca = marca
        self.cor = cor
        self.placa = placa
        self.ano = ano
        self.modelo = modelo

    def ligar(self):
        print("carro ligado")
    def dados(self):
        print(f"marca: {self.marca}")
        print(f"cor: { self.cor}")
        print(f"placa: {self.placa}")
        print(f"ano: { self.ano}")
        print(f"modelo: {self.modelo}")
carro1 = Automovel("3281")
carro1.dados()
carro1.ligar()
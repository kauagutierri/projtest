from Estudante import  Estudante

matricula = input("matricula: ")
nome = input("digite seu nome: ")
idade = input("digite sua idade: ")
nota = input("digite sua nota ")

aluno = Estudante(matricula, nome, idade, nota)
aluno.dados()
def soma(n1,n2):
    res = n1 + n2
    return res


def multi (n1,n2):
    res = n1 * n2 
    return res

def div (n1,n2):
    res = n1 / n2
    return res

def sub(n1,n2):
    res = n1 - n2
    return res
def poten (n1,n2):
    res = n1 ** n2 
    return res

x = soma( 10, 50)
a = multi(5,5)
b = div(80,80)
c = sub(15,15)
d = poten(20,20)
print(x + a + d)
















from funcoes import*

print(" bomm dia ")
n1 = str(input(" ola, escreva seu nome por favor: "))
n2 = float(input(" escreva um numero desejado: "))
n3 = float(input(" escreva um numero desejado: "))

x = div(n2,n3)
y = soma(n2,n3)
resultado = x + y
print(f" ola, {n1}, o resultado é {resultado}")
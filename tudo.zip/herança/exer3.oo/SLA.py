from Ingresso import Ingresso
from Vip import IngressoVIP


def pegar_bebida(self):
        if self.open_bar >= 100:
            return "Você pode pegar uma bebida."
        else:
            return "Este ingresso não inclui open bar."

def acessar_camarote(self):
        if self.camarote >= 100:
            return "Você pode acessar o camarote."
        else:
            return "Este ingresso não inclui acesso ao camarote."

ingresso_normal = Ingresso(100, "Pista")
print(ingresso_normal.preco)  
print(ingresso_normal.mostrar_setor())  
ingresso_normal.alterar_preco(120)
print(ingresso_normal.preco)  

ingresso_vip = IngressoVIP(250, "VIP", True, True, True, True)
print(ingresso_vip.preco)  
print(ingresso_vip.mostrar_setor())  
print(ingresso_vip.pegar_bebida())  
print(ingresso_vip.acessar_camarote()) 
n1 = int(input("qual Ingresso voce quer:  1 ou 2:  "))
n2 = str(input("digite o a forma de pagamento: "))
if n1 == 1:
     print("Ingresso normal")
elif n1 ==  2:
     print("ingresso vip, bem vindo")
else:
     pass




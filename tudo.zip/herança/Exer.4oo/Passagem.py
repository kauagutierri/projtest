class Passagem:
    def __init__(self, preco, assento):
        self.preco = preco
        self.assento = assento

    def alterar_preco(self, novo_preco):
        self.preco = novo_preco

    def escolher_assento(self, novo_assento):
        self.assento = novo_assento

class PassagemAviao(Passagem):
    def __init__(self, preco, assento, portaodeembarque, checkin):
        super().__init__(preco, assento)
        self.embarque = portaodeembarque
        self.checkin = checkin

    def decolar(self):
        print("O avião está decolando.")

class PassagemBus(Passagem):
    def __init__(self, preco, assento, placa, leito):
        super().__init__(preco, assento)
        self.placa = placa
        self.leito = leito

    def abastecer(self):
        print("O ônibus está sendo abastecido.")


aviao = PassagemAviao(1000, "12A", "G8", "Online")
print(f"Preço: {aviao.preco}, Assento: {aviao.assento}, Portão de Embarque: {aviao.embarque}, Check-in: {aviao.checkin}")
aviao.decolar()
aviao.alterar_preco(1200)
print(f"Novo preço da passagem de avião: {aviao.preco}")

bus = PassagemBus(150, "32B", "XYZ-1234", True)
print(f"Preço: {bus.preco}, Assento: {bus.assento}, Placa: {bus.placa}, Leito: {bus.leito}")
bus.abastecer()
bus.escolher_assento("45C")
print(f"Novo assento da passagem de ônibus: {bus.assento}")

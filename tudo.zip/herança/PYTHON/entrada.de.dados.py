######perimetro###3
 
print(" bom dia guys!!!")
lado = int(input("\n digite o do quadrado: "))
perimetro = lado + lado + lado + lado 
print("\n o valor da area é: ",perimetro)

area  = lado * lado
print(" o valor da area é: ",area)

print("  bom dia ♡")
n1 = float(input(" digite o valor do real: "))
res =  n1  * 5.27
print(" o resultado é: ♡",res)
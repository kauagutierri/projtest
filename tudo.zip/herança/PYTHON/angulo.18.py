print(" bom dia♡")
n1 = float(input(" digite o  valor angulo: "))
print(" espere um segundo")
res = n1*180/3.14
print("o resultado é: ",res)
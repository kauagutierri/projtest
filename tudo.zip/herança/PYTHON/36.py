print(" bom dia")
n1 = float(input(" digite o valor do salario: "))
res = n1 + ( n1 *( 25/100))
print("o seu resultado é: ",res)
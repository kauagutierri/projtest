print(" bom dia ♡ ")
n1 = float(input(" digite o valor do quadrado: "))
res = n1 * 10000
print(f"a conversão em metros é {res} ♡ ")

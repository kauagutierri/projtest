print(" bom dia")
n1  = float(input("digite o valor do raio: "))
n2 = float(input(" escreva da altura: "))
res = 3.14 *(n1 * n1)* n2
print(" o resultado é: ",res)
print(" bom dia, usuario♡")
n1 = float(input("digite a distancia do quilometro: "))
res = n1/1,61
print(" o resultado é: ",res)
 
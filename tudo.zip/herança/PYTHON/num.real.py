print(" bom dia!!")
n1 = float(input(" digite o valor do numero: "))
resul = n1 * n1 
print("\n o resultado é: ",resul)
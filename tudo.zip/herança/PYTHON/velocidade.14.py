print(" bom dia guys")

n1 = float(input(" digite o valor km/h: "))
resul = n1*3.6
print("\n o resultado é: ",resul)

 
##########segundo programa com python
a = int(input("digite um numero: "))
b = int(input(" digite outro numero: "))

c = a + b 
print(f"\n o  resultado é: {c}")

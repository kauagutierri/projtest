#######vamo

print(" bom dia ♡ ")
n1 = float(input(" digite a massa em quilograma: "))
res = n1/0.45 
print(f"a conversão emm libra é {res} ♡ ")

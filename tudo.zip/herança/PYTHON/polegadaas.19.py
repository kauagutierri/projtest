print(" bom dia ♡")
n1 = int(input("por  ggentileza,\ndigite o valor da polegada: "))
res = n1*2.54
print("o resultado é: ",res)
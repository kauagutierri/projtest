####toleve
print("bom diaaa!!")
n1 = int(input("digite seu numero: "))
suce = (n1 + 1) * 3
print("\n o sucessor é: ",suce)
antes = (n1 - 1) * 2
print(" o resultado do seu antessecor é: ",antes)
result = suce + antes 
print("\n o resultado é:",result)

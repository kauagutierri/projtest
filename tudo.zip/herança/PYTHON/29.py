print(" bom dia ♡ ")
n1 = float(input(" digite um  numero: "))
n2 = float(input(" digite o segundo numero: "))
n3 = float(input(" digite o terceiro numero: "))
res = (n1 ** 2) + (n2 ** 2) + ( n3 ** 2 )
print("  o resultado é ♡ ", res)


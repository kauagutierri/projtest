print("  bomm  dia ")
n1 = float(input(" digite a quantidade de dias trrabalhados: "))
res = (n1 * 30)
result = res * 0.08
final = res - result
print("o resultado é: ",final)
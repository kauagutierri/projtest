print(" bom dia, vamos calcular ")
n1 = int(input(" digite sua data de nascimento: "))
res = (2024 - n1) - 1
print(" o resultado é: ",res)
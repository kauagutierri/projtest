print(" bom dia guys!!")

c = float(input("digite o numero da temperadura: "))
resul = c * (9.0/5.0) + 32.0
print(" a temperatura é: ",resul)


########toleve
print(" bom dia ♡ ")
n1 = float(input(" digite o comprimento em jardas: "))
res = 0.91*n1
print(f"a conversão emm libra é {res} ♡ ")

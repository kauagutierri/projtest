####### trianguloo

a =int(input(" Digite um numero: "))
b = int(input(" Digite outro numero: "))
c = a * b / 2

print(f"\n o resultado é {c}")
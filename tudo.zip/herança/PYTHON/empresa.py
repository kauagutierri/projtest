########saida de dados###
print("olá, bom dia!!!!")
nome =(input("\n digite seu nome: "))
data =(input("\n qual o data de vencimento: "))
mes = (input("\n digite qual o mes de vencimento: "))
valor = (input("\n digite o valor da fatura: "))

print(f" olá, {nome} \n a sua fatura com vencimento {data} de {mes} no valor de {valor} esta fechada ")
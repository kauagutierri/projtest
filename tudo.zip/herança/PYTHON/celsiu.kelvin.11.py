print(" bom dia")
n1 = float(input(" digite a temperatura: "))
res = n1 + 273.15
print(" o resultado é: ",res)
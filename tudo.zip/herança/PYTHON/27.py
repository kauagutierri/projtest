print(" bom dia ♡ ")
n1 = float(input(" digite o valor do quadrado: "))
res = n1 * 0.0001
print(f"a conversão em  hectere é {res} ♡ ")

print(" bom dia ♡")
n1 = int(input("por gentileza,\ndigite o valor metro cubicos: "))
res = 1000*n1
print("o resultado é: ",res)
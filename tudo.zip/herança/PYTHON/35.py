print(" bom dia")
n1 = float(input(" escreva um numero: "))
res = (12/100) * n1
print("o seu resultado é: ",res)
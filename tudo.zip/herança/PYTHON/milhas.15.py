
print(" bom dia amores ♡ ")

n1 = float(input ("digite o valor da milha: "))
res = 1.61 * n1 
print(" o resulta é :",res)



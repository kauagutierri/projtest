print(" bom dia  ♡ ")
n1 = float(input("escreva um numero: "))
n2 = float (input("escreva o segundo numero: "))
res = ( n1*n1 ) + (n2 *n2 )

resul = res ** (1/2)
print((" o resultado é ",resul))
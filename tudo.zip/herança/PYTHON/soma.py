#############meu primeiro programa com python
a = 10
b = 40
c = a + b
print(" o resultado é: ",c)

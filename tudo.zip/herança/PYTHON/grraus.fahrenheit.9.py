#######quero vazzar 



print(" bom dia")

n1 = float(input(" digite  o valor da temperatura: "))
res = 5.0*(n1 - 32.0)/9.0
print("\n o valor da temperatura é: ",res)
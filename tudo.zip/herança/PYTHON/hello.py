print("hello word")


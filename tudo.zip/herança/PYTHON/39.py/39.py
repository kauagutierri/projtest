########toleve

print(" bom dia ﮩ٨ـﮩﮩ٨ـ♡ﮩ٨ـﮩﮩ٨ـ")
n1 = int(input(" digite o valor das horas trabalhadas: "))
n2 = int(input(" digite o valor do numero de horas trabalhada: "))
res = n1 / n2 
result = res * (10/100)
print(" o resulta é: ",result)

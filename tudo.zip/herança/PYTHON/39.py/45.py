######ntoliso

print(" bom dia ")
n1 = float(input(" digite a quantidad de camisa pequeno: "))
n2 = float(input(" digite a quantidade de camisa media: "))
n3 = float(input(" digite a quantidade de camise grande: "))
res = (n1 * 35) + ( n2 * 45) + ( n3 * 55)
print(f"o valor arrecadado foi {res}")

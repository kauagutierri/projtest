####tolove



print(" ❥ bom dia guys")
PESO_QUEIJO = 50
PESO_PRESUNTO = 50
PESO_HAMBURGUER = 100

quantidade_sanduiches = int(input("Quantidade de sanduíches: "))

queijo = quantidade_sanduiches * 2 * PESO_QUEIJO / 1000
presunto = quantidade_sanduiches * PESO_PRESUNTO / 1000
hamburguer = quantidade_sanduiches * PESO_HAMBURGUER / 1000

print(f"Queijo: {queijo:.2f} kg, Presunto: {presunto:.2f} kg, Hambúrguer: {hamburguer:.2f} kg")
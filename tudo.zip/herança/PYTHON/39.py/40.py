####bom dia 



print(" bom dia ❤ ")
n1 = float(input("digite o valor do salario: "))
res1 = n1 * 0.05
res = n1 + res1
imposto = res * 0.07
res = res - imposto
print("o resultado é: ",res)
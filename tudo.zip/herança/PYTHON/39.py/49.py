######tolove[]

print("bom dia")
n1 = float(input(" digite a quantidade de latas: "))
n2 = float(input(" digite a quantidade de garrafas 600ml:  "))
n3 = float(input(" digite a quantidade de garrafas 2ml:  "))
x = n1 * 350
z = n2 * 600
y = n3 * 2000
print(f" o  valor de litro de refri é {x + z + y}: ")
###to leve
print(" bom dia")
n1 = float(input(" digite o  valor: "))
x = n1 - 10
print(f" o total é com desconto de 10% fica: {x} ")

n2 = x / 3
print(f"o valor de cada parcela em 3 vezes fica {n2}")

n3  = x
z = 0.05 * n3
print(f"a comissão do vendedor, se for a vista, seá de {z}")

n4 = 0.05 * n1
print(f"o valor d a comissão do venndedor,, no caso da venda ser  parcelada fica: {n4}")
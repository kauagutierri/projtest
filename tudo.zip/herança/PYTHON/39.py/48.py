########toleve


print(" bom dia ")
n1 = float(input(" digite a quantidade de frago: "))
res = n1 * 11
print(f" a quantidade de chip gasto com franco é {res}")
######toleve
print(" bom dia ")
n1 =  float(input(" digite a quantidade venda de pães: "))
n2 = float(input("\n digite o valor da broa: "))
res = (n1 * 0.12) + (n2 * 1.50 )
result = 0.10 * res
print(f"o resultado é {result}, e o valor de vendas foi {res}")

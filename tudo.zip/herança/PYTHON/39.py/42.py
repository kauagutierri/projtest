#####toleve

print(" bom dia ")
n1 = float(input(" escreva a altura do degrau: "))
n2 = float(input(" escreva a a altura voce quer alcançar: "))
result = n2 * 100
res = result/ n1

print(f" o resultado é {res}")

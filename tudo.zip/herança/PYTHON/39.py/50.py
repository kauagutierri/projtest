import math

n1 = print(input("Digite  o ponto x1: "))
n2 = print(input("Digite  o ponto y1: "))
n3 = print(input("Digite  o ponto x2: "))
n4 = print(input("Digite  o ponto y1: "))
res = math.sqrt ((n1 - n3) **2 + (n2 - n4)**2)
print(f"a distancia entre os ponto é: {res}") 
if res > 10:
    print("longe")
else:
    print("perto")
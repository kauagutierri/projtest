#####toleve

print(" bom dia ")
n1 = float(input(" ✿ escreva o valor do preso do prato: "))
res = (n1/1000) * 57
print(f"o valor a pagar é {res}")

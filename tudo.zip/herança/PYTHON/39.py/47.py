###toleve
print("BOM DIA ")
n1 = float(input(" digite horas normais tralhadas: "))
n2 = float(input(" digite a quantidades de horas extras: "))
x = n1 * 32.50
y = n2 * 44.50
result = x + y
print("Valor bruto: ",result)
inss = result * 0.11
print("Valor liquido: ",result - inss)

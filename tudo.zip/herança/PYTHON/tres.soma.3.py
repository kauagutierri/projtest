print("hello guys")
n1 = int(input(" digite o valor do primeiro numero: "))
n2 = int(input(" digite o valor do segundo numero: "))
n3 = int(input(" digite o valor do terceiro numero: "))
resul = n1 + n2 + n3 
print("\n o resultado é: ",resul)
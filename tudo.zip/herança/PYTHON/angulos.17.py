print("bom dia amores♡ ")
n1 = float(input(" digite o valor do angulos: "))
res = n1*3.14/180
print(" o valor do radiano é: ",res)
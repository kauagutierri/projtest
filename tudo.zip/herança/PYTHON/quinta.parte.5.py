#####bom diaa####

print(" good night!!")
n1 = float(input(" digite o valor do numero: "))
resul = n1 / 5
print("\n o resultado é: ",resul)
print(" helllo guys!!!! ")
n1 = int(input(" digite o numero: "))
print("\n o seu numero é: ",n1)
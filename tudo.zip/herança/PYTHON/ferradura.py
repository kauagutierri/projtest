cavalos = int(input( " quantidade de cavalo: "))
res = cavalos *  4
print(f" voce precisade {res} ferradura:")
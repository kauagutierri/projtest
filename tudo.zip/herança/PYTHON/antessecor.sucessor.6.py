print(" bom dia!!")
n1 = int(input(" digite  um numero: "))
antes = n1 - 1 
print("\n o antessecor é :",antes)
suce = n1 + 1
print("\n o antessecor é: ",suce)
#######nao é sextouuuuu####

print(" bom dia ♡ ")
n1 = float(input(" digite o valor do metro : "))
res = (n1 / 0.91)
print(f"a conversão emm libra é {res} ♡ ")

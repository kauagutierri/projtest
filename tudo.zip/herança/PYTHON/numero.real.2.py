print(" bom dia!!!")
n1 = float(input(" digite o  numero: "))
print("\n o seu numero é ",n1)
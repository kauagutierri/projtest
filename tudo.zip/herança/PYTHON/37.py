print(" bom dia ")
premio = 780000.00
n1= premio * 0.46
n2= premio * 0.32
n3 =  n1 - n2
print(" o resultado é: ",n3)
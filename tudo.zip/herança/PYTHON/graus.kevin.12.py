print(" bom dia guys!!")
n1 = float(input(" digite a temperatura: "))
res = n1 - 273.15
print(" o resultado final é: ",res)
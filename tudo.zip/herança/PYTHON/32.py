raio = int(input("digite o  valor do raio: "))
num = 3.14 * (raio * raio )
print(f" o  valor do é:",num)

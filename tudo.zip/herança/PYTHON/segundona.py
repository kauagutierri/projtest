#######COMENTARIO - ENTRADA E SAIDA DE DADOS##################

print(" bom dia!!!")
print("----" * 30)
print(" sistema de conversa numerica")
num = int(input( " digite seu numero: "))
num = num*2
print (" o dobro de seu numero foi ",num)
print("  fim do algoritmo")




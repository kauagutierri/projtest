def Maiornumero(n1,n2,n3):
    numero = [n1,n2,n3]
    print(f"o maior numero é: {max(numero)}")

Maiornumero(57, 45,2)

import math

def calcula_volume_esfera(raio):
    volume = (4/3) * math.pi * (raio ** 3)
    return volume

def testa_calculo_volume_esfera():
    raios = [1, 2, 3, 4, 5]
    for raio in raios:
        volume = calcula_volume_esfera(raio)
        print(f"Raio: {raio} -> Volume da Esfera: {volume:.2f}")

testa_calculo_volume_esfera()

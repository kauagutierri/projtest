def Reverter(n1):
    n1 = str(n1)
    inverso = "".join(reversed(n1))
    print(inverso)

numero = int(input("digite um numero: "))
Reverter(numero) 
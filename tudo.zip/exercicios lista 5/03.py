def verificar_numero(numero):
    if numero > 0:
        return 1
    elif numero < 0:
        return -1
    else:
        return 0
numero = 5
resultado = verificar_numero(numero)
print(f"O número {numero} é {'positivo' if resultado == 1 else 'negativo' if resultado == -1 else 'zero'} e o valor de retorno é {resultado}.")

def temperatura(calcius):
    f = calcius *(9.0//5.0) + 32
    print(f"{f}")

temperatura(float(input("digite a temperatura: ")))
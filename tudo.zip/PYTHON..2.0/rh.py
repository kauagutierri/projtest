
cargo = input(" digite seu cargo: ")
nome = input(" digite seu nome: ")
email = input(" digite seu email: ")
idade = int(input(" escreva sua idade: "))
if idade >= 18:
    print("parabens voce passou para a proxima fase ")
    curso = input(" voce tem curso? ")
    if curso == "sim":
        print(" voce passou para a proxima fase ")
        nota = float(input(" digite sua nota: "))
        if nota >= 7:
            print(" voce passou e ")
        else:
            print(" voce nao passou, realmente é uma pena")
    else:
        print(" uma pena, voce nao passou, mais sorte na proxima vez ")

else:
    print(" obrigado pela participação, voce nao passou")
print(" bom dia 🙄")

n1 = int(input(" digite sua idade meu nobre: "))

if (n1 >= 5) and (n1 <= 7):
    print(f"bom meu nobre, tu é infantil A ")
elif (n1 >= 8) and (n1 <= 10):
   print(f"bom meu nobre, tu é infantil B")
elif (n1 >= 11) and (n1 <= 13):
    print(" bom meu nobre, tu é juvenil A")
elif (n1 >= 14) and (n1 <= 17):
    print(" meu nobre tu é juvenil B")
elif n1 >= 18:
    print(" meu nobre tu é senior: ")
####bomdia😳👍
def calcular_nota_final(nota_lab, nota_semestral, nota_exame):
    n1 = 2
    n2 = 3
    n3 = 5
    
    media_final = (nota_lab * n1 + nota_semestral * n2 + nota_exame * n3) / (n1 + n2 + n3)
    
    return media_final
def verificar_status(nota_final):
    if nota_final < 3.0:
        return "Reprovado"
    elif nota_final < 6.0:
        return "Recuperação"
    else:
        return "Aprovado"
nota_lab = float(input("Digite a nota do trabalho de laboratório (0 a 10)😐😜: "))
nota_semestral = float(input("Digite a nota da avaliação semestral (0 a 10)😳👍: "))
nota_exame = float(input("Digite a nota do exame final (0 a 10)😳😳😳: "))
media_final = calcular_nota_final(nota_lab, nota_semestral, nota_exame)
status_aluno = verificar_status(media_final)
print("A nota final do aluno é:", media_final)
print("O aluno está", status_aluno)

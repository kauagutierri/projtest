def calcular_preco_final(valor, estado):
    impostos = {'MG': 0.07, 'SP': 0.12, 'RJ': 0.15, 'MS': 0.08}
    if estado in impostos:
        taxa_imposto = impostos[estado]
        preco_final = valor * (1 + taxa_imposto)
        return preco_final
    else:
        return "Erro: Estado inválido."
valor_produto = float(input("Digite o valor do produto: R$ "))
estado_destino = input("Digite a sigla do estado destino (MG, SP, RJ, MS): ").upper()
resultado = calcular_preco_final(valor_produto, estado_destino)
print("Preço final do produto:", resultado if type(resultado) == float else resultado)

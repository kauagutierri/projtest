######toleve

n1 = int(input("escreva um numero:😐 "))
n2 = int(input(" escreva outro numero🤩: "))
n3 = float(input("  escreva o terceiro numero:😲 "))
x = n1 + (n2/2)
y = (n1 * 3) + n3
z = n3 ** 3

print(f"o valor de x é {x} ")
print(f"o valor de x é {y} ")
print(f"o valor de x é {z} ")
res = x + y + z
print(f"soma total é {res} ")

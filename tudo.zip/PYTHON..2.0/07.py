###############todboa
preco_aquisicao = float(input("Digite o valor de aquisição do produto: "))

if preco_aquisicao < 50:
    preco_venda = preco_aquisicao *0.45
else:
    preco_venda = preco_aquisicao * 0.3
print(f"O valor de venda do produto é: R$ {preco_venda:.2f}")

print(" BOM DIA ")
n1 = float(input(" digite a distancia em km: "))
n2 =float(input(" digite o valor consumido: "))
n3 = n1/n2
if n3 < 8:
    print(" venda o carro URGENTE")
elif n3 >= 8 and n3 <= 14:
    print(" economico")
elif n3 > 12:
    print=(" super economico ")
else:
    print(" erro 404😪")
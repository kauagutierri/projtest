def calcular_peso_ideal(altura, sexo):
    if sexo.lower() == 'masculino':
        peso_ideal = (72.7 * altura) - 58
    elif sexo.lower() == 'feminino':
        peso_ideal = (62.1 * altura) - 44.7
    else:
        return "Sexo inválido. Por favor, insira 'masculino' ou 'feminino'."

    return peso_ideal

def main():
    altura = float(input("Digite a altura da pessoa em metros: "))
    sexo = input("Digite o sexo da pessoa (masculino/feminino): ")

    peso_ideal = calcular_peso_ideal(altura, sexo)
    if isinstance(peso_ideal, str):
        print(peso_ideal)
    else:
        print("O peso ideal para uma pessoa com altura {:.2f}m e sexo {} é {:.2f}kg.".format(altura, sexo, peso_ideal))

if __name__ == "__main__":
    main()

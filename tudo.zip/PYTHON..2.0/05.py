
sexo =(input(" digite o seu sexo F ou M: "))
sexo = sexo.lower()

if sexo == "f":
    print("você é mulher:👩🤶 ")
elif sexo == "m": 
    print(" você é homem 🗿 🍷 ")
else:
    print("sexo invalido😶😪")



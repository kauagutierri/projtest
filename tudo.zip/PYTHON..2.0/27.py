def soma(num1, num2):
    return num1 + num2

def diferenca(num1, num2):
    return abs(num1 - num2)

def produto(num1, num2):
    return num1 * num2

def divisao(num1, num2):
    if num2 != 0:
        return num1 / num2
    else:
        return "Erro: divisão por zero!"

def menu():
    print("Escolha a opção:")
    print("1- Soma de 2 números.")
    print("2- Diferença entre 2 números (maior pelo menor).")
    print("3- Produto entre 2 números.")
    print("4- Divisão entre 2 números (o denominador não pode ser zero).")

def main():
    menu()
    opcao = int(input("Opção: "))

    if opcao in [1, 2, 3, 4]:
        num1 = float(input("Digite o primeiro número: "))
        num2 = float(input("Digite o segundo número: "))

        if opcao == 1:
            print("Resultado da soma:", soma(num1, num2))
        elif opcao == 2:
            print("Resultado da diferença:", diferenca(num1, num2))
        elif opcao == 3:
            print("Resultado do produto:", produto(num1, num2))
        elif opcao == 4:
            print("Resultado da divisão:", divisao(num1, num2))
    else:
        print("Opção inválida!")

if __name__ == "__main__":
    main()

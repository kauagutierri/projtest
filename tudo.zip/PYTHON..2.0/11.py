import math


numero = float(input("Digite um número: "))
if numero > 0: 
    quadrado = numero ** 2
    print(f"O número digitado ao quadrado é: {quadrado}")
    raiz_quadrada = math.sqrt(numero)
    print(f"A raiz quadrada do número digitado é: {raiz_quadrada}")
else:
    print("O número digitado não é positivo. Não é possível calcular o quadrado ou a raiz quadrada.")


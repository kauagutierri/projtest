def calcular_media_ponderada(nota1, nota2, nota3):
    media = (nota1 + nota2 + (nota3 * 2)) / 4

    return media
def verificar_aprovacao(media):
    if media >= 60:
        return "Aprovado"
    else:
        return "Reprovado"
nota1 = float(input("Digite a nota da primeira prova: "))
nota2 = float(input("Digite a nota da segunda prova: "))
nota3 = float(input("Digite a nota da terceira prova: "))
media_aluno = calcular_media_ponderada(nota1, nota2, nota3)*10
situacao = verificar_aprovacao(media_aluno)
print("A média do aluno é:", media_aluno)
print("Situação do aluno:", situacao)


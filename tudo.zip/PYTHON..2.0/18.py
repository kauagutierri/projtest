###
print("bom dia ")

n1 = float(input(" digite o  valor do salario:  "))
n2 = float(input(" digite o valor do emprestimo:  "))
res = 0.2* n1
if (n2 > res):
    print(" emprestimo não consedido")
else:
    print(" emprestimo consedido ")



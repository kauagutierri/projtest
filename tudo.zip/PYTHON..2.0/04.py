####tolve

n1 = int(input("digite um numero 🐮: "))
n2 = int(input("digite mais um numero 🙄: "))
n3 = int(input("digite outro numero 😡🤬💔: "))

res = sorted([n1,n2, n3])
print(res)
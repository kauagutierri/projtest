print("bom dia")

nota1 = float(input("Digite a primeira nota: "))
nota2 = float(input("Digite a segunda nota: "))
if 0.0 <= nota1 <= 10.0 and 0.0 <= nota2 <= 10.0:
    media = (nota1 + nota2) / 2
    print(f"A média das notas é: {media:.2f}")
else:
    print("Uma ou ambas as notas fornecidas não são válidas. As notas devem estar entre 0.0 e 10.0.")

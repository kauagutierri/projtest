def nome_mes(numero):
    if numero == 1:
        return "Janeiro"
    elif numero == 2:
        return "Fevereiro"
    elif numero == 3:
        return "Março"
    elif numero == 4:
        return "Abril"
    elif numero == 5:
        return "Maio"
    elif numero == 6:
        return "Junho"
    elif numero == 7:
        return "Julho"
    elif numero == 8:
        return "Agosto"
    elif numero == 9:
        return "Setembro"
    elif numero == 10:
        return "Outubro"
    elif numero == 11:
        return "Novembro"
    elif numero == 12:
        return "Dezembro"
    else:
        return "Número inválido"
numero = int(input("Digite um número entre 1 e 12: "))
print("O mês correspondente ao número", numero, "é", nome_mes(numero))

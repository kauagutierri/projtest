n1 = int(input(" escreva o ano: "))
if n1 % 4 == 0:
    print(" o ano é bissexto")
else: 
    print
    (" o ano é bissexto")
    
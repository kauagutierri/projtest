n1 = 34


if(n1 > 34):
    print(" esta calor 🥵🌡️")
elif( n1 <= 34 and n1 >= 24):
    print("esta agradavel 😍👉👈")
else: 
    print("esta frio🥶🥶🤬🤬🤬🤬🤬")
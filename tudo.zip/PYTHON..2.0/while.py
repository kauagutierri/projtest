num = 10
while(num >= 0):
    print(" seqcu",num)
    num = num - 1
    
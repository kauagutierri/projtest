print(" bom dia ")

n1 = int(input(" digite um numero😎😋: "))
n2 = int(input(" digite outro numero😴😫: "))
n3 = int(input(" digite mais um numero🙄🙄🙄😡🤬:  "))

if n1 < n2 < n3: 
    print(" o resultado é😍😳 crescente ")
else:
    print("o resultado não é crescente😪😪😓")

###############3toleve 

print(" ola, bom dia😍 ")
n1 = float(input(" digite um numero: "))

def calcular_salario(n1):
    valor_por_hora = 40.50
    salario_bruto = n1 * valor_por_hora
    
    if salario_bruto > 2500:
        salario_excedente = salario_bruto - 2500
        imposto_renda = salario_excedente * 0.11
        salario_liquido = salario_bruto - imposto_renda
    else:
        salario_liquido = salario_bruto
    
    return salario_liquido

salario_liquido = calcular_salario(n1)
print("Salário líquido: R$", salario_liquido)


turno = input("Em que turno você estuda? Digite M para Matutino, V para Vespertino ou N para Noturno: ")

if turno.upper() == 'M':
    print("Bom Dia!, você estuda de manhã")
elif turno.upper() == 'V':
    print("Boa Tarde! você estuda de tarde ")
elif turno.upper() == 'N':
    print("Boa Noite! voce estuda de noite ")
else:
    print("Valor Inválido!")
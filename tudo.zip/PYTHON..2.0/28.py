########tolve

n1 = int(input("digite a idade do trabalhador : "))
n2 = int(input(" digite as horas trabalhadas : "))

if n1 >= 65 or n2 >=30:
    print(" voce pode se aposentar ")
else:
    print(" voce nao pode se aposentar ")
    
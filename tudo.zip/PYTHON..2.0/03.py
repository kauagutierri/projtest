####toleve


n1 = int(input(" digite um numero:😀 "))
n2 = int(input(" digite outro numero:😝 "))

if( n1 > n2):
    print(f"o numero maior é 😎 {n1}")
else: 
    print(f" seu numero é menor 😫 {n1}")
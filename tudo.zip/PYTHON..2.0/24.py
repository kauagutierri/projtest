#####bom dia 

n1 = float(input(" o lado menor: "))
n2 = float(input("  digite o lado maior: "))
n3 = float(input(" digite a altura do tripezio: "))

res = (n1 + n2)*n3
result = res / 2
print(" o resultado é ",result)
########toleve

n1 = int(input(" digite um numero:🤑 "))
if(n1 >= 10):
    print("seu resultado é maior👀 ")
else: 
    if(n1 <= 10):
        print("seu resutado é menor 😓")
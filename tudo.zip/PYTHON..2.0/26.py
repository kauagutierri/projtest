##########tileves


a = int(input("escreva o primeiro  valor: "))
b =  int(input(" digiite outro numero: "))
c = int(input(" digite mais uum numero: "))

if  a + b > c and  a * c > b and b + c > a:
    print(" os  valores podem formar um triangulos")
else:
    print(" os valores nãp podem formar um triangulo")

if  a == b == c:
    print(" o triangulo é equilatero ")
elif a == b or a == c or b == c:
    print("o triangulo isosceles")
elif a != b or a != c or b != c:
    print("  o  triangulo é escaleno. ")
else:
    pass


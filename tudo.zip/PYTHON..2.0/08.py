print("bom dia ")

def verificar_tipo_dados(dados):
    tipos = []
    for dado in dados:
        if isinstance(dado, int):
            tipos.append("int")
        elif isinstance(dado, float):
            tipos.append("float")
        elif isinstance(dado, str):
            tipos.append("string")
        else:
            tipos.append("tipo desconhecido")
    return tipos

entrada1 = input("Digite o primeiro dado: ")
entrada2 = input("Digite o segundo dado: ")
entrada3 = input("Digite o terceiro dado: ")


try:
    entrada1 = int(entrada1)
except ValueError:
    try:
        entrada1 = float(entrada1)
    except ValueError:
        pass

try:
    entrada2 = int(entrada2)
except ValueError:
    try:
        entrada2 = float(entrada2)
    except ValueError:
        pass

try:
    entrada3 = int(entrada3)
except ValueError:
    try:
        entrada3 = float(entrada3)
    except ValueError:
        pass

tipos = verificar_tipo_dados([entrada1, entrada2, entrada3])
for i in range(3):
    print(f"O tipo de dado armazenado na variável {i+1} é: {tipos[i]}")




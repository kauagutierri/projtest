#### bom dia 
def soma_algarismos(numero):
    soma = 0
    while numero > 0:
        soma += numero % 10
        numero //= 10
    return soma

numero = int(input("Digite um número inteiro maior que zero: "))

if numero <= 0:
    print("Número inválido")
else:
    resultado = soma_algarismos(numero)
    print("A soma dos algarismos do número é:", resultado)



nome = []
while len(nome) < 11:
    nomes = input(" digite um nome: ")
    nome.append (nomes)
print(nome)
print(len(nome))
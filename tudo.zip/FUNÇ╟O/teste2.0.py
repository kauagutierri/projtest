fruits =['apple', 'kiwi',  'watermelon', 'banana', 'strawberry']
for item in fruits:
    print(item)

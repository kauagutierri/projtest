vet1 = []
vet2 = []
i = 0
while i < 5:
    valor = int(input("escreva um numero: "))
    vet1.append(valor)
    vet2.append(vet1[i] * 5 )
    i = i +1
print(f"vetor 1 = {vet1}")
print(f" vator 2 = {vet2}")

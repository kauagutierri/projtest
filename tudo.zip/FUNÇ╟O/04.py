print("bom dia")
x = 1
while x < (101):
    print(x)
    x += 1

print("")
print("")


for i in range(1, 101):
    print(i)
n1 = int(input("escreva um numero: "))
x = 0
i = 2
while x < n1:
    print(i)
    i += 2
    x += 1
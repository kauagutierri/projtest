print("bom dia ")
i = 10
while i > (-1):
    print(i)
    i = i - 1 
terminar = False
notas = []
while terminar == False:
    nota = int(input("digite a numero ou -1 para terminar: "))
    if nota == -1:
        terminar = True
    print(max(notas))
    print(min(notas))
    notas.append(nota)
print(notas)
print(notas)
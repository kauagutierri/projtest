n = int(input("DIGITE QUANTOS NUMEROS: "))
i = 1
cont = 0
while cont < n:
    print(i)
    i += 2
    cont += 1
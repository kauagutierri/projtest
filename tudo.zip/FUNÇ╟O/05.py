print("bom dia")
x = 0
while x < (1000001):
    print(x)
    x += 1000








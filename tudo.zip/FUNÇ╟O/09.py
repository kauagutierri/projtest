print(' bom dia ')
nome = []
while len(nome) < 10:
     nome.append(int(input(" digite os numeros ")))
print("media",min(nome))
print(" media", max(nome))
x = 12
for i in range(x):
    print("*" * i)
print("bom dia ")
n1 = int(input(" escreva o numero: "))
for i in range(11):
    print(f'{n1*i}')
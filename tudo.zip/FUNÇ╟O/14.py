
n1 = int(input("escreva um numero "))
i = 0
c = 0
while c < n1 and i <= n1:
    print(i)
    i += 2
    c += 1